"""Action Ledger — approval gate with persistence and notifications.

Key improvements over the original:
- **asyncio.Event** replaces busy-polling in ``wait_for_approval()``.
- Pending actions are persisted to a JSON file so they survive restarts.
- A pluggable notification mechanism lets upstream code register
  callbacks (e.g. push to WebSocket, send email) when actions are queued.
"""

import asyncio
import json
import os
import uuid
import datetime
import logging
from typing import Callable, Dict, Optional

from config.settings import AUTONOMY_PROFILE

logger = logging.getLogger(__name__)


# Components that must NEVER be auto-approved regardless of autonomy profile.
# These involve physical-world effects, financial cost, or irreversible actions.
NEVER_AUTO_APPROVE_COMPONENTS = frozenset({
    "ImageGen",        # Costs money per generation
    "VideoGen",        # Costs money per generation
    "CodeExecution",   # Arbitrary code execution risk
    "Printer",         # Physical world effect
    "Printer3D",       # Physical world effect + material cost
    "Finance",         # Financial transactions — money movement
    "Commerce",        # Purchase / checkout actions
})


class ActionLedger:
    PERSIST_PATH = "action_ledger_pending.json"

    def __init__(self):
        self.pending_actions: Dict[str, dict] = {}
        self.audit_log = "action_ledger_audit.log"
        self.profile = AUTONOMY_PROFILE

        # Per-action events for efficient await (replaces busy-polling)
        self._events: Dict[str, asyncio.Event] = {}

        # Notification callbacks — called when a new action is queued
        self._notification_callbacks: list[Callable[[dict], None]] = []

        # Restore previously persisted pending actions
        self._load_persisted()

    # ----------------------------------------------------------------
    # Persistence
    # ----------------------------------------------------------------

    def _persist(self):
        """Write current pending actions to disk (fire-and-forget best-effort)."""
        try:
            with open(self.PERSIST_PATH, "w") as f:
                json.dump(self.pending_actions, f, indent=2, default=str)
        except Exception:
            logger.exception("Failed to persist action ledger")

    def _load_persisted(self):
        """Load previously persisted pending actions from disk."""
        if not os.path.exists(self.PERSIST_PATH):
            return
        try:
            with open(self.PERSIST_PATH, "r") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for action_id, action_data in data.items():
                    if action_data.get("status") == "pending":
                        self.pending_actions[action_id] = action_data
                        self._events[action_id] = asyncio.Event()
                logger.info(
                    "Restored %d pending actions from persistence", len(self.pending_actions)
                )
        except Exception:
            logger.exception("Failed to load persisted action ledger")

    # ----------------------------------------------------------------
    # Notification
    # ----------------------------------------------------------------

    def register_notification_callback(self, callback: Callable[[dict], None]):
        """Register a callback invoked when a new action is queued.

        The callback receives the action dict and can, for example,
        push it over a WebSocket or send an email.
        """
        self._notification_callbacks.append(callback)

    def _notify(self, action_data: dict):
        for cb in self._notification_callbacks:
            try:
                cb(action_data)
            except Exception:
                logger.exception("Notification callback raised an error")

    # ----------------------------------------------------------------
    # Audit logging
    # ----------------------------------------------------------------

    def _log_audit(self, action_data, approved_by="human"):
        try:
            with open(self.audit_log, "a") as f:
                f.write(
                    f"{datetime.datetime.now().isoformat()} | "
                    f"{approved_by.upper()} | "
                    f"{action_data['component']}.{action_data['action']} | "
                    f"{action_data['params']}\n"
                )
        except Exception:
            logger.exception("Failed to write audit log")

    # ----------------------------------------------------------------
    # Core logic
    # ----------------------------------------------------------------

    def _should_auto_approve(self, component, risk_level):
        # Never auto-approve dangerous components regardless of profile
        if component in NEVER_AUTO_APPROVE_COMPONENTS:
            return False
        if self.profile == "GUEST":
            return False
        if self.profile == "STANDARD":
            if risk_level == "low":
                return True
        if self.profile == "POWER":
            if component in ("PCControl", "BrowserControl") and risk_level != "critical":
                return True
            if risk_level == "low":
                return True
        return False

    def queue_action(self, component, action, params, risk_level="high"):
        action_id = str(uuid.uuid4())
        action_data = {
            "id": action_id,
            "component": component,
            "action": action,
            "params": params,
            "risk_level": risk_level,
            "status": "pending",
            "timestamp": datetime.datetime.now().isoformat(),
        }

        # Auto-approve based on profile
        if self._should_auto_approve(component, risk_level):
            action_data["status"] = "approved"
            self._log_audit(action_data, approved_by="auto")
            self.pending_actions[action_id] = action_data
            self._events[action_id] = asyncio.Event()
            self._events[action_id].set()  # already approved
            self._persist()
            return action_id

        self.pending_actions[action_id] = action_data
        self._events[action_id] = asyncio.Event()
        self._persist()
        self._notify(action_data)
        return action_id

    async def wait_for_approval(self, action_id, timeout=300):
        """Wait for approval using ``asyncio.Event`` (no busy-polling).

        Returns ``True`` if approved, ``False`` if rejected or timed out.
        """
        event = self._events.get(action_id)
        if event is None:
            return False

        # Already approved?
        if self.pending_actions.get(action_id, {}).get("status") == "approved":
            return True

        logger.info(
            "Action %s awaiting manual approval (Profile: %s)",
            action_id,
            self.profile,
        )

        try:
            await asyncio.wait_for(event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            return False

        status = self.pending_actions.get(action_id, {}).get("status")
        if status == "approved":
            self._log_audit(self.pending_actions[action_id], approved_by="human")
            return True
        return False

    def approve_action(self, action_id):
        if action_id in self.pending_actions:
            self.pending_actions[action_id]["status"] = "approved"
            event = self._events.get(action_id)
            if event:
                event.set()
            self._persist()
            return True
        return False

    def reject_action(self, action_id):
        if action_id in self.pending_actions:
            self.pending_actions[action_id]["status"] = "rejected"
            event = self._events.get(action_id)
            if event:
                event.set()  # unblock waiters (they'll check status)
            self._persist()
            return True
        return False

    # ----------------------------------------------------------------
    # Voice-native approval
    # ----------------------------------------------------------------

    async def wait_for_voice_approval(
        self,
        action_id: str,
        speaker=None,
        listener=None,
        timeout: int = 60,
    ) -> bool:
        """Speak the pending action aloud and wait for a spoken yes/no.

        Workflow:
            1. Speak the action description via the speaker module.
            2. Use the listener to capture a spoken response.
            3. Parse intent: yes → approve_action(), no/timeout → reject_action().
            4. Ambiguous responses: ask once more, then reject.

        Args:
            action_id: The queued action to approve or reject.
            speaker: FridaySpeaker instance (or any object with ``speak(text)``).
            listener: FridayListener instance (or any object with ``record_audio``).
            timeout: Seconds to wait for a response (default 60).

        Returns:
            True if approved, False if rejected or timed out.
        """
        action_data = self.pending_actions.get(action_id)
        if not action_data:
            logger.warning("wait_for_voice_approval: unknown action %s", action_id)
            return False

        # Already approved?
        if action_data.get("status") == "approved":
            return True

        # Build a spoken description
        component = action_data.get("component", "unknown")
        act = action_data.get("action", "unknown")
        params = action_data.get("params", {})
        description = (
            f"Action pending: {component} wants to {act}. "
            f"Parameters: {params}. "
            f"Say yes to approve, or no to reject."
        )

        # Step 1: Speak the action
        if speaker and hasattr(speaker, "speak"):
            try:
                await speaker.speak_async(description)
            except Exception as exc:
                logger.warning("Voice approval: speak failed: %s", exc)
        else:
            logger.info("Voice approval: no speaker — printing to console")
            print(f"[VOICE APPROVAL] {description}")

        # Step 2: Capture spoken response
        response_text = ""
        if listener and hasattr(listener, "record_audio"):
            try:
                import tempfile
                import os

                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                    tmp_path = tmp.name

                recorded = await asyncio.to_thread(
                    listener.record_audio, tmp_path, 8
                )

                if recorded:
                    # Transcribe the recorded audio
                    try:
                        from voice.transcriber import Transcriber
                        transcriber = Transcriber()
                        response_text = await asyncio.to_thread(
                            transcriber.transcribe, tmp_path
                        )
                    except Exception as exc:
                        logger.warning("Voice approval: transcription failed: %s", exc)
                        response_text = ""
                    finally:
                        try:
                            os.unlink(tmp_path)
                        except OSError:
                            pass
            except Exception as exc:
                logger.warning("Voice approval: recording failed: %s", exc)

        # Step 3: Parse intent
        approved = self._parse_voice_intent(response_text)

        if approved is None:
            # Ambiguous — ask once more
            if speaker and hasattr(speaker, "speak"):
                try:
                    await speaker.speak_async(
                        "I didn't catch that. Please say yes or no."
                    )
                except Exception:
                    pass

            # Listen again
            response_text = ""
            if listener and hasattr(listener, "record_audio"):
                try:
                    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                        tmp_path = tmp.name
                    recorded = await asyncio.to_thread(
                        listener.record_audio, tmp_path, 8
                    )
                    if recorded:
                        try:
                            from voice.transcriber import Transcriber
                            transcriber = Transcriber()
                            response_text = await asyncio.to_thread(
                                transcriber.transcribe, tmp_path
                            )
                        except Exception:
                            pass
                        finally:
                            try:
                                os.unlink(tmp_path)
                            except OSError:
                                pass
                except Exception:
                    pass

            approved = self._parse_voice_intent(response_text)

            # Still ambiguous? Reject
            if approved is None:
                approved = False

        # Step 4: Approve or reject
        if approved:
            self.approve_action(action_id)
            self._log_audit(action_data, approved_by="voice")
        else:
            self.reject_action(action_id)
            self._log_audit(action_data, approved_by="voice_rejected")

        return approved

    @staticmethod
    def _parse_voice_intent(text: str):
        """Parse a spoken response into yes / no / None (ambiguous).

        Returns:
            True  — positive intent detected
            False — negative intent detected
            None  — ambiguous / unclear
        """
        if not text:
            return None

        text_lower = text.lower().strip()

        yes_words = {"yes", "yeah", "yep", "sure", "okay", "ok", "approve", "go ahead", "do it", "confirm", "affirmative"}
        no_words = {"no", "nope", "nah", "reject", "deny", "cancel", "stop", "don't", "negative", "refuse"}

        for word in yes_words:
            if word in text_lower:
                return True

        for word in no_words:
            if word in text_lower:
                return False

        return None


# Module-level singleton
_ledger: Optional[ActionLedger] = None


def get_ledger() -> ActionLedger:
    global _ledger
    if _ledger is None:
        _ledger = ActionLedger()
    return _ledger
