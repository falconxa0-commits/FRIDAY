"""Wake-on-First-Contact Module.

Detects the first wake-word activation after startup and, if during
morning hours, automatically triggers the Morning Briefing.

Conditions:
  - Must be the first contact since process start.
  - Current hour must be between 6 AM and 11 AM (configurable).
  - ``check_and_trigger()`` returns True only once per process lifetime.
"""

import logging
from datetime import datetime
from typing import Callable, Optional

logger = logging.getLogger("WakeOnContact")


class WakeOnContact:
    """Detect first-contact wake-word and trigger morning briefing."""

    # Morning hours range (24h format).  Override at init if desired.
    DEFAULT_MORNING_START = 6
    DEFAULT_MORNING_END = 11

    def __init__(
        self,
        morning_start: int = DEFAULT_MORNING_START,
        morning_end: int = DEFAULT_MORNING_END,
        on_trigger: Optional[Callable] = None,
    ):
        self.morning_start = morning_start
        self.morning_end = morning_end
        self.on_trigger = on_trigger  # async callback for morning briefing
        self._first_contact_occurred = False

    def is_morning_hours(self) -> bool:
        """Return True if current time is within morning hours."""
        hour = datetime.now().hour
        return self.morning_start <= hour < self.morning_end

    def check_and_trigger(self) -> bool:
        """Check if this is the first contact and morning hours.

        Returns True **exactly once** per process lifetime when:
          1. This is the first wake-word activation.
          2. The current time is within morning hours.

        After the first call (regardless of return value), subsequent
        calls always return False — the "first contact" window has passed.
        """
        if self._first_contact_occurred:
            return False

        self._first_contact_occurred = True

        if self.is_morning_hours():
            logger.info(
                "Wake-on-contact: first contact during morning hours "
                "(%02d:00–%02d:00) — triggering morning briefing",
                self.morning_start,
                self.morning_end,
            )

            # Fire the callback if provided
            if self.on_trigger:
                try:
                    result = self.on_trigger()
                    # If the callback is async, the caller should await it.
                    # Here we just log the return value.
                    if result is not None:
                        logger.info("Morning briefing callback returned: %s", type(result).__name__)
                except Exception as exc:
                    logger.error("Morning briefing callback error: %s", exc)

            return True

        logger.info(
            "Wake-on-contact: first contact outside morning hours "
            "(current hour: %02d) — no auto-briefing",
            datetime.now().hour,
        )
        return False

    async def check_and_trigger_async(self) -> bool:
        """Async version of ``check_and_trigger()``.

        If ``on_trigger`` is an async callable, it will be awaited.
        """
        if self._first_contact_occurred:
            return False

        self._first_contact_occurred = True

        if self.is_morning_hours():
            logger.info(
                "Wake-on-contact: first contact during morning hours — triggering briefing"
            )

            if self.on_trigger:
                try:
                    import asyncio
                    result = self.on_trigger()
                    if asyncio.iscoroutine(result):
                        await result
                except Exception as exc:
                    logger.error("Morning briefing async callback error: %s", exc)

            return True

        logger.info(
            "Wake-on-contact: first contact outside morning hours (hour=%02d)",
            datetime.now().hour,
        )
        return False

    def reset(self):
        """Reset the first-contact flag (e.g. for testing)."""
        self._first_contact_occurred = False
