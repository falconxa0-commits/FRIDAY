"""Chat API routes — SSE streaming, non-streaming POST, history, and stats."""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional, AsyncGenerator
import json
import logging

logger = logging.getLogger("friday.api.chat")

router = APIRouter()

# ---------------------------------------------------------------------------
# Use the singleton brain from api.main instead of creating a new one per request
# ---------------------------------------------------------------------------


class ChatRequest(BaseModel):
    message: str
    user_name: Optional[str] = "User"


async def _get_brain():
    """Return the singleton FridayBrain (delegates to main._get_brain)."""
    from api.main import _get_brain
    return await _get_brain()


# ---------------------------------------------------------------------------
# POST /api/chat  — non-streaming (collects full response then returns JSON)
# ---------------------------------------------------------------------------

@router.post("/chat")
async def chat(request: ChatRequest):
    try:
        brain = await _get_brain()
        responses = []
        async for chunk in brain.chat_stream(request.message, request.user_name):
            responses.append(chunk)
        return {"response": "".join(responses)}
    except Exception as e:
        logger.exception("Chat error")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# GET /api/chat/stream?message=...  — SSE streaming
# ---------------------------------------------------------------------------

@router.get("/chat/stream")
async def chat_stream(
    message: str = Query(...),
    user_name: str = Query("User"),
):
    """Server-Sent Events endpoint for streaming chat responses."""

    async def event_generator() -> AsyncGenerator[str, None]:
        try:
            brain = await _get_brain()

            async for chunk in brain.chat_stream(message, user_name):
                # Detect tool-call markers from the brain
                # Brain emits things like "\n[System: tool_name(...)]\n"
                # We wrap text and tool calls in structured SSE payloads
                if chunk.startswith("\n[System:") and chunk.endswith("]\n"):
                    # Tool call notification
                    tool_info = chunk.strip()
                    payload = json.dumps({"type": "tool_call", "raw": tool_info})
                    yield f"data: {payload}\n\n"
                else:
                    # Regular text chunk
                    payload = json.dumps({"type": "text", "content": chunk})
                    yield f"data: {payload}\n\n"

            # Signal completion
            yield "data: [DONE]\n\n"

        except Exception as e:
            logger.exception("SSE stream error")
            error_payload = json.dumps({"type": "error", "message": str(e)})
            yield f"data: {error_payload}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# GET /api/chat/history  — conversation history
# ---------------------------------------------------------------------------

@router.get("/chat/history")
async def get_history():
    try:
        brain = await _get_brain()
        return {"history": brain.conversation_history}
    except Exception as e:
        logger.exception("History error")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# POST /api/chat/clear  — clear conversation context
# ---------------------------------------------------------------------------

@router.post("/chat/clear")
async def clear_context():
    try:
        brain = await _get_brain()
        brain.clear_context()
        return {"status": "success", "message": "Conversation context cleared."}
    except Exception as e:
        logger.exception("Clear context error")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# GET /api/chat/stats  — brain statistics
# ---------------------------------------------------------------------------

@router.get("/chat/stats")
async def get_stats():
    try:
        brain = await _get_brain()
        return brain.get_stats()
    except Exception as e:
        logger.exception("Stats error")
        raise HTTPException(status_code=500, detail=str(e))
