# Project FRIDAY — Personal AI Assistant

FRIDAY is a Python-based personal AI assistant that connects to multiple LLM providers (GLM, Claude, Gemini, GPT) and integrates with real services (weather, calendar, Spotify, smart home, etc.). It ships with a FastAPI backend, a web UI, and optional voice control. The default provider is GLM-4-Flash from ZhipuAI, which is free — no paid API keys are required to use the core features.

**What FRIDAY actually is:** A hobbyist AI assistant project that wraps multiple LLM APIs behind a unified chat interface, adds tool calling, memory, and basic agent orchestration. It works out of the box with a free GLM API key and can optionally connect to paid providers for better quality. Some features (voice, vision, smart home) require additional hardware or API keys.

## Feature Status

| Feature | Status | Notes |
|---------|--------|-------|
| **Multi-Brain Chat** (GLM/Claude/Gemini/GPT) | ✅ Working | GLM free tier; others require paid keys |
| **GLM-4-Flash (Default)** | ✅ Working | Free, no paid key needed |
| **Web Search** | ✅ Working | Via GLM built-in web_search tool |
| **Image Generation** | ✅ Working | CogView-3 via Z.ai (free tier, limited) |
| **Video Generation** | ✅ Working | CogVideoX via Z.ai (free tier, limited) |
| **Vision Analysis** | ✅ Working | GLM-4V (free tier) |
| **Local Fallback (Ollama)** | ✅ Working | Requires Ollama running locally |
| **Action Receipts** | ✅ Working | Verified receipts for every action |
| **Human-in-Loop Ledger** | ✅ Working | Async approval queue for dangerous actions |
| **Plugin/Integration SDK** | ✅ Working | Auto-discovered integrations |
| **Agent Coordination** | ✅ Working | Parallel agent execution |
| **Memory Management** | ✅ Working | CRUD + RAG retrieval |
| **Council Mode** | ✅ Working | Multi-provider comparison |
| **Tamper-Evident Audit Log** | ✅ Working | SHA-256 hash chain |
| **Cost Tracker** | ✅ Working | Per-provider token/cost tracking |
| **Trust Audit (Hellfire)** | ✅ Working | 8 adversarial checks |
| **Weather / Calendar** | ✅ Working | Requires API keys |
| **Spotify / Smart Home** | ✅ Working | Requires OAuth tokens |
| **Deep Research** | ✅ Working | GLM web search + synthesis |
| **Voice I/O** | ⚠️ Partial | Requires Picovoice + ElevenLabs keys |
| **Screen Analysis** | ⚠️ Partial | Requires display access |
| **Docker Deployment** | ✅ Working | Docker Compose included |

## Quick Start

### Option 1: One-command install
```bash
bash setup.sh
```

### Option 2: Manual setup
```bash
# Install dependencies
pip install -r requirements.txt

# Set your free GLM API key
export GLM_API_KEY="your-key-from-open.bigmodel.cn"

# Start the API server
uvicorn api.main:app --host 0.0.0.0 --port 8000
```

### Option 3: Docker
```bash
docker-compose up -d
```

## Getting a Free GLM API Key

1. Go to [open.bigmodel.cn](https://open.bigmodel.cn)
2. Create a free account
3. Go to API Keys in your dashboard
4. Create a new key and copy it
5. Set it: `export GLM_API_KEY="your-key"`

No credit card required. GLM-4-Flash is free for all users.

## Configuration

All configuration is via environment variables:

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `GLM_API_KEY` | **Yes** | — | Free ZhipuAI key (required for core features) |
| `ANTHROPIC_API_KEY` | No | — | Claude provider |
| `OPENAI_API_KEY` | No | — | GPT provider |
| `GEMINI_API_KEY` | No | — | Gemini provider |
| `BRAIN_PROVIDER` | No | `glm` | Default LLM provider |
| `AUTONOMY_PROFILE` | No | `GUEST` | GUEST / STANDARD / POWER |
| `FRIDAY_API_TOKEN` | No | — | API auth token (dev mode if unset) |

## Z.ai Free Tier Rate Limits

| Model | Cost | Rate Limit | Context |
|-------|------|------------|---------|
| GLM-4-Flash | Free | ~100 req/min | 128K tokens |
| GLM-4V | Free | ~50 req/min | 8K tokens |
| CogView-3 (image) | Free (limited/day) | Varies | — |
| CogVideoX (video) | Free (limited/day) | Varies | — |
| Web Search | Free | Subject to GLM limits | — |

Rate limits vary by account. See [open.bigmodel.cn/pricing](https://open.bigmodel.cn/pricing) for details.

## Benchmark Results

The benchmark suite (`benchmarks/tasks.json` + `benchmarks/run_benchmark.py`) covers tasks including GLM web search, image/video generation, deep research, code tutor, and morning briefing.

**Last run: 2026-06-20 — 0% pass rate.** All 8 tasks failed with 401 authentication errors because the test was run without a valid GLM_API_KEY. Results will improve once re-run with a working key.

## Cost Estimates

With GLM as the default provider, FRIDAY costs **$0.00** to run. Optional paid providers:

| Provider | Input Cost | Output Cost |
|----------|-----------|-------------|
| GLM (free) | $0.00/1K | $0.00/1K |
| Claude Sonnet | $0.003/1K | $0.015/1K |
| GPT-4o | $0.0015/1K | $0.006/1K |
| Gemini 2.0 Flash | $0.000075/1K | $0.0003/1K |

Use the built-in cost tracker (`core/cost_tracker.py`) to monitor usage.

## Architecture

```
FRIDAY/
├── api/              # FastAPI server + routes
├── core/             # Brain, memory, emotions, personality
├── config/           # Settings and identity
├── integrations/     # Weather, Spotify, smart home, etc.
├── skills/           # Deep research, morning briefing, etc.
├── agents/           # Task, coding, research, writing agents
├── voice/            # Wake word, speech, transcription
├── vision/           # Screen reader, OCR, presence
├── control/          # PC control, browser, file manager
├── database/         # Supabase, vector store
├── scripts/          # Hellfire audit, smoke tests
├── benchmarks/       # Benchmark suite
└── apps/             # Web UI, mobile, desktop
```

## Ethics & Safety

- **Ethical Sentinel Engine** evaluates every action before execution
- **Human-in-the-Loop Ledger** requires approval for destructive/financial actions
- **Tamper-Evident Audit Log** — SHA-256 hash chain that detects any modification
- **Hellfire Audit** — 8 adversarial checks run on every build
- Financial and physical actions are **never** auto-approved, regardless of autonomy profile

## License

MIT
