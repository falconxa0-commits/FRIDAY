"""Checkout Integration — real payment gateway or honest not_implemented.

Supports Stripe sandbox/test mode for real payment processing, or returns
``not_implemented`` if no gateway is configured.  Never fabricates
"transaction completed".  The confirmation gate blocks at the most
permissive setting — all transactions require explicit approval.

Inherits from BaseIntegration.
"""

import asyncio
import datetime
import logging
import os
from typing import Optional

from integrations.base import BaseIntegration

logger = logging.getLogger(__name__)


class Checkout(BaseIntegration):
    """Real checkout integration with Stripe sandbox or honest not_implemented."""

    @property
    def name(self) -> str:
        return "Commerce"

    def __init__(self):
        self._stripe_available: Optional[bool] = None
        self._stripe_key = os.getenv("STRIPE_SECRET_KEY", "")
        self._stripe_mode = "test" if self._stripe_key.startswith("sk_test_") else "live"

    # ------------------------------------------------------------------
    # Availability
    # ------------------------------------------------------------------

    def available(self) -> bool:
        """Return True if Stripe is configured."""
        if self._stripe_available is not None:
            return self._stripe_available

        if not self._stripe_key:
            logger.info("No STRIPE_SECRET_KEY configured — Checkout unavailable")
            self._stripe_available = False
            return False

        try:
            import stripe
            stripe.api_key = self._stripe_key
            # Verify the key works by listing balance
            stripe.Balance.retrieve()
            self._stripe_available = True
            logger.info(f"Stripe checkout available (mode: {self._stripe_mode})")
        except ImportError:
            logger.info("stripe package not installed — Checkout unavailable")
            self._stripe_available = False
        except Exception as exc:
            logger.warning(f"Stripe key verification failed: {exc}")
            self._stripe_available = False

        return self._stripe_available

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def list_actions(self):
        return ["create_payment_intent", "confirm_payment", "get_payment_status"]

    async def execute(self, action: str, params: Optional[dict] = None) -> dict:
        params = params or {}

        # ALL checkout actions require approval regardless of autonomy level
        # This is enforced by the ledger's NEVER_AUTO_APPROVE_COMPONENTS.

        if not self.available():
            return self._make_response(
                "not_implemented",
                "No payment gateway configured. Set STRIPE_SECRET_KEY to enable checkout. "
                "Use a test key (sk_test_...) for sandbox mode.",
            )

        try:
            if action == "create_payment_intent":
                return await self._create_payment_intent(params)
            elif action == "confirm_payment":
                return await self._confirm_payment(params)
            elif action == "get_payment_status":
                return await self._get_payment_status(params)
            else:
                return self._make_response(
                    "not_implemented",
                    f"Action '{action}' is not supported by Checkout.",
                )
        except Exception as exc:
            logger.error(f"Checkout execute failed: {exc}")
            return self._make_response("error", str(exc))

    # ------------------------------------------------------------------
    # Payment actions
    # ------------------------------------------------------------------

    async def _create_payment_intent(self, params: dict) -> dict:
        """Create a Stripe PaymentIntent.

        Params:
            amount (float): Amount in the smallest currency unit (e.g., cents).
            currency (str): Three-letter currency code. Default "usd".
            description (str, optional): Description of the payment.
        """
        import stripe

        amount = params.get("amount")
        if amount is None:
            return self._make_response("error", "Missing required parameter: amount")

        currency = params.get("currency", "usd")
        description = params.get("description", "FRIDAY Checkout")

        try:
            def _create():
                return stripe.PaymentIntent.create(
                    amount=int(amount),
                    currency=currency,
                    description=description,
                    metadata={"source": "friday_ai"},
                )

            intent = await asyncio.to_thread(_create)

            return self._make_response(
                "success",
                f"Payment intent created: {intent.id} for {amount} {currency.upper()}",
                receipt_data={
                    "intent_id": intent.id,
                    "amount": amount,
                    "currency": currency,
                    "status": intent.status,
                    "client_secret": intent.client_secret,
                    "mode": self._stripe_mode,
                },
            )
        except stripe.error.CardError as e:
            return self._make_response("error", f"Card error: {e.user_message}")
        except stripe.error.InvalidRequestError as e:
            return self._make_response("error", f"Invalid request: {str(e)}")
        except Exception as e:
            return self._make_response("error", f"Payment intent creation failed: {str(e)}")

    async def _confirm_payment(self, params: dict) -> dict:
        """Confirm a payment intent.

        Params:
            intent_id (str): The PaymentIntent ID to confirm.
            payment_method (str, optional): Payment method ID.
        """
        import stripe

        intent_id = params.get("intent_id")
        if not intent_id:
            return self._make_response("error", "Missing required parameter: intent_id")

        payment_method = params.get("payment_method")

        try:
            def _confirm():
                kwargs = {}
                if payment_method:
                    kwargs["payment_method"] = payment_method
                return stripe.PaymentIntent.confirm(intent_id, **kwargs)

            intent = await asyncio.to_thread(_confirm)

            return self._make_response(
                "success",
                f"Payment {intent_id} confirmed. Status: {intent.status}",
                receipt_data={
                    "intent_id": intent_id,
                    "status": intent.status,
                    "amount": intent.amount,
                    "currency": intent.currency,
                    "mode": self._stripe_mode,
                },
            )
        except stripe.error.CardError as e:
            return self._make_response("error", f"Card declined: {e.user_message}")
        except stripe.error.InvalidRequestError as e:
            return self._make_response("error", f"Invalid request: {str(e)}")
        except Exception as e:
            return self._make_response("error", f"Payment confirmation failed: {str(e)}")

    async def _get_payment_status(self, params: dict) -> dict:
        """Get the status of a payment intent.

        Params:
            intent_id (str): The PaymentIntent ID to check.
        """
        import stripe

        intent_id = params.get("intent_id")
        if not intent_id:
            return self._make_response("error", "Missing required parameter: intent_id")

        try:
            def _retrieve():
                return stripe.PaymentIntent.retrieve(intent_id)

            intent = await asyncio.to_thread(_retrieve)

            return self._make_response(
                "success",
                f"Payment {intent_id} status: {intent.status}",
                receipt_data={
                    "intent_id": intent_id,
                    "status": intent.status,
                    "amount": intent.amount,
                    "currency": intent.currency,
                    "created": intent.created,
                    "mode": self._stripe_mode,
                },
            )
        except stripe.error.InvalidRequestError as e:
            return self._make_response("error", f"Payment not found: {str(e)}")
        except Exception as e:
            return self._make_response("error", f"Status check failed: {str(e)}")
