"""Writing Style skill — Friday learns your writing voice and matches it.

Reads a sample of your writing (emails, documents, notes) and learns
your style: sentence length, vocabulary level, formality, humour,
argument structure. When writing anything on your behalf, Friday
matches your actual style instead of a generic "professional" template.
"""
from __future__ import annotations

import asyncio
import logging
import re
from typing import Any, Dict, List, Optional

from skills.base import BaseSkill

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Style analysis (heuristic — no LLM required)
# ---------------------------------------------------------------------------

class StyleProfile:
    """A snapshot of a user's writing style."""

    def __init__(self):
        self.avg_sentence_length: float = 0.0
        self.max_sentence_length: int = 0
        self.min_sentence_length: int = 0
        self.vocabulary_size: int = 0
        self.formality_score: float = 0.5  # 0=very casual, 1=very formal
        self.humor_score: float = 0.0      # 0=serious, 1=very humorous
        self.use_contractions: float = 0.0 # 0=never, 1=always
        self.use_first_person: float = 0.0 # 0=never, 1=always
        self.favorite_words: List[str] = []
        self.exclamation_density: float = 0.0
        self.question_density: float = 0.0
        self.paragraph_count: int = 0
        self.avg_paragraph_length: float = 0.0
        self.sample_count: int = 0

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}

    @classmethod
    def from_dict(cls, d: dict) -> "StyleProfile":
        p = cls()
        for k, v in d.items():
            setattr(p, k, v)
        return p


def analyze_writing_sample(text: str) -> StyleProfile:
    """Analyse a writing sample and return a StyleProfile.

    All metrics are computed from real text features — no LLM required.
    """
    profile = StyleProfile()
    if not text or not text.strip():
        return profile

    # Split into sentences (crude but works for most prose)
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]
    if not sentences:
        return profile

    # Sentence lengths
    sentence_lengths = [len(s.split()) for s in sentences]
    profile.avg_sentence_length = sum(sentence_lengths) / len(sentence_lengths)
    profile.max_sentence_length = max(sentence_lengths)
    profile.min_sentence_length = min(sentence_lengths)

    # Vocabulary size (unique words, case-insensitive)
    words = re.findall(r'\b[a-z]+\b', text.lower())
    unique_words = set(words)
    profile.vocabulary_size = len(unique_words)

    # Favorite words (top 10 most frequent, excluding stopwords)
    from collections import Counter
    stopwords = {
        "the", "a", "an", "and", "or", "but", "if", "then", "is", "are",
        "was", "were", "be", "been", "being", "have", "has", "had", "do",
        "does", "did", "will", "would", "could", "should", "may", "might",
        "must", "can", "to", "of", "in", "on", "at", "by", "for", "with",
        "about", "as", "into", "through", "during", "before", "after",
        "this", "that", "these", "those", "i", "you", "he", "she", "it",
        "we", "they", "me", "him", "her", "us", "them",
    }
    word_counts = Counter(w for w in words if w not in stopwords and len(w) > 3)
    profile.favorite_words = [w for w, _ in word_counts.most_common(10)]

    # Formality — count formal vs casual markers
    formal_markers = ["therefore", "however", "furthermore", "moreover",
                      "consequently", "nevertheless", "accordingly",
                      "subsequently", "thus", "hence"]
    casual_markers = ["yeah", "ok", "okay", "gonna", "wanna", "kinda",
                      "stuff", "things", "pretty", "really", "super"]
    formal_count = sum(1 for w in words if w in formal_markers)
    casual_count = sum(1 for w in words if w in casual_markers)
    total_markers = formal_count + casual_count
    if total_markers > 0:
        profile.formality_score = formal_count / total_markers
    else:
        profile.formality_score = 0.5

    # Humor — count exclamation marks + humorous cues
    humor_cues = ["haha", "lol", "funny", "joke", "kidding", "ha"]
    humor_count = sum(1 for w in words if w in humor_cues)
    profile.humor_score = min(humor_count / 50.0, 1.0)

    # Contractions
    contractions = ["don't", "can't", "won't", "i'm", "you're", "we're",
                    "they're", "isn't", "wasn't", "weren't", "haven't",
                    "hasn't", "hadn't", "doesn't", "didn't", "couldn't",
                    "shouldn't", "wouldn't", "it's", "that's", "there's"]
    contraction_count = sum(text.lower().count(c) for c in contractions)
    profile.use_contractions = min(contraction_count / max(len(sentences), 1), 1.0)

    # First person
    first_person = sum(text.lower().count(p) for p in ["i ", "i'm", "i've", "i'll", "i'd", "me ", "my ", "mine", "we ", "our "])
    profile.use_first_person = min(first_person / max(len(words), 1), 1.0)

    # Exclamation + question density
    profile.exclamation_density = text.count("!") / max(len(sentences), 1)
    profile.question_density = text.count("?") / max(len(sentences), 1)

    # Paragraph analysis
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    profile.paragraph_count = len(paragraphs)
    if paragraphs:
        profile.avg_paragraph_length = sum(len(p.split()) for p in paragraphs) / len(paragraphs)

    profile.sample_count = 1
    return profile


def merge_profiles(profiles: List[StyleProfile]) -> StyleProfile:
    """Merge multiple StyleProfiles into one (averaging metrics)."""
    if not profiles:
        return StyleProfile()
    merged = StyleProfile()
    n = len(profiles)
    merged.avg_sentence_length = sum(p.avg_sentence_length for p in profiles) / n
    merged.max_sentence_length = int(sum(p.max_sentence_length for p in profiles) / n)
    merged.min_sentence_length = int(sum(p.min_sentence_length for p in profiles) / n)
    merged.vocabulary_size = int(sum(p.vocabulary_size for p in profiles) / n)
    merged.formality_score = sum(p.formality_score for p in profiles) / n
    merged.humor_score = sum(p.humor_score for p in profiles) / n
    merged.use_contractions = sum(p.use_contractions for p in profiles) / n
    merged.use_first_person = sum(p.use_first_person for p in profiles) / n
    merged.exclamation_density = sum(p.exclamation_density for p in profiles) / n
    merged.question_density = sum(p.question_density for p in profiles) / n
    merged.paragraph_count = int(sum(p.paragraph_count for p in profiles) / n)
    merged.avg_paragraph_length = sum(p.avg_paragraph_length for p in profiles) / n
    # Favorite words — merge and take top 10
    from collections import Counter
    all_words = [w for p in profiles for w in p.favorite_words]
    merged.favorite_words = [w for w, _ in Counter(all_words).most_common(10)]
    merged.sample_count = sum(p.sample_count for p in profiles)
    return merged


# ---------------------------------------------------------------------------
# Style application — adjust text to match a profile
# ---------------------------------------------------------------------------

def apply_style(text: str, profile: StyleProfile) -> str:
    """Adjust text to match the given style profile.

    Heuristic adjustments:
      - Shorten sentences if profile.avg_sentence_length is low
      - Add contractions if profile.use_contractions is high
      - Add formality markers if profile.formality_score is high
      - Add exclamation marks if profile.exclamation_density is high
      - Use first person if profile.use_first_person is high
    """
    if not text or not text.strip():
        return text

    result = text

    # Contractions: replace "do not" → "don't" if profile uses contractions
    if profile.use_contractions > 0.5:
        contraction_map = {
            "do not": "don't", "does not": "doesn't", "did not": "didn't",
            "cannot": "can't", "will not": "won't", "would not": "wouldn't",
            "should not": "shouldn't", "could not": "couldn't",
            "is not": "isn't", "was not": "wasn't", "were not": "weren't",
            "have not": "haven't", "has not": "hasn't", "had not": "hadn't",
            "it is": "it's", "that is": "that's", "there is": "there's",
            "I am": "I'm", "you are": "you're", "we are": "we're",
            "they are": "they're",
        }
        for full, contracted in contraction_map.items():
            result = result.replace(full, contracted)

    # Formality: add formal connectors if profile is formal
    if profile.formality_score > 0.7:
        # Replace "But" at start of sentence with "However,"
        result = re.sub(r'(?<=\.)\s+But ', '. However, ', result)

    # Exclamation density
    if profile.exclamation_density > 0.3:
        # Add exclamation to short sentences that end in period
        def add_exclamation(match):
            sent = match.group(0)
            if len(sent.split()) < 8 and not sent.endswith("?"):
                return sent[:-1] + "!"
            return sent
        result = re.sub(r'[^.!?]*\.', add_exclamation, result, count=2)

    # Casual: if profile is casual, simplify
    if profile.formality_score < 0.3:
        casual_map = {
            "utilize": "use", "subsequently": "then", "approximately": "about",
            "fundamentally": "basically", "additionally": "also",
        }
        for formal, casual in casual_map.items():
            result = result.replace(formal, casual)
            result = result.replace(formal.capitalize(), casual.capitalize())

    return result


# ---------------------------------------------------------------------------
# Skill class (plugs into FridayBrain's skill system)
# ---------------------------------------------------------------------------

class WritingStyleSkill(BaseSkill):
    """Skill that learns the user's writing style and applies it to outputs."""

    def __init__(self):
        self._profiles: List[StyleProfile] = []
        self._merged_profile: Optional[StyleProfile] = None

    @property
    def name(self): return "writing_style"

    @property
    def description(self): return (
        "Learns your writing style from samples and applies it to "
        "anything Friday writes on your behalf."
    )

    @property
    def trigger_phrases(self): return [
        "learn my writing style",
        "match my writing style",
        "write in my voice",
    ]

    async def run(self, brain, params=None) -> dict:
        """Run the skill. Params:
            - action: 'learn' | 'apply' | 'profile'
            - text: sample text (for 'learn') or text to restyle (for 'apply')
        """
        params = params or {}
        action = params.get("action", "profile")
        text = params.get("text", "")

        if action == "learn":
            if not text:
                return {"status": "error", "message": "Missing 'text' for learning"}
            profile = analyze_writing_sample(text)
            self._profiles.append(profile)
            self._merged_profile = merge_profiles(self._profiles)
            return {
                "status": "success",
                "message": f"Learned from sample ({len(text)} chars). Total samples: {len(self._profiles)}",
                "receipt": {
                    "type": "skill_receipt",
                    "data": self._merged_profile.to_dict(),
                },
            }

        if action == "apply":
            if not text:
                return {"status": "error", "message": "Missing 'text' to apply style to"}
            if not self._merged_profile:
                return {"status": "error", "message": "No style profile learned yet. Run with action='learn' first."}
            styled = apply_style(text, self._merged_profile)
            return {
                "status": "success",
                "message": "Text restyled to match your writing style.",
                "receipt": {
                    "type": "skill_receipt",
                    "data": {
                        "original": text,
                        "restyled": styled,
                        "profile_summary": {
                            "avg_sentence_length": self._merged_profile.avg_sentence_length,
                            "formality_score": self._merged_profile.formality_score,
                            "use_contractions": self._merged_profile.use_contractions,
                        },
                    },
                },
            }

        if action == "profile":
            if not self._merged_profile:
                return {"status": "error", "message": "No style profile learned yet."}
            return {
                "status": "success",
                "message": "Style profile ready",
                "receipt": {
                    "type": "skill_receipt",
                    "data": self._merged_profile.to_dict(),
                },
            }

        return {"status": "error", "message": f"Unknown action: {action}"}
