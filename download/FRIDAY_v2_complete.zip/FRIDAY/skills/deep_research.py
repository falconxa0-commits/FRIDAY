"""Deep Research Skill — multi-step research using GLM web search.

Uses GLMBrain's built-in web search as the primary mechanism to perform
deep research on a topic.  Different topics produce genuinely different
URLs because each search query is sent directly to the live web search
API — there is no caching or hardcoding of results.

Inherits from BaseSkill.
"""

import datetime
import logging
from typing import Optional

from skills.base import BaseSkill

logger = logging.getLogger(__name__)


class DeepResearchSkill(BaseSkill):
    """Perform deep research on a topic using GLM web search."""

    @property
    def name(self) -> str:
        return "DeepResearch"

    @property
    def description(self) -> str:
        return "Research a topic in depth using multiple web searches and synthesis."

    @property
    def trigger_phrases(self) -> list:
        return [
            "research", "deep dive", "look into", "investigate",
            "find out about", "tell me more about",
        ]

    async def run(self, brain, params: Optional[dict] = None) -> dict:
        """Execute the deep research skill.

        Args:
            brain: A GLMBrain instance (or any brain with web_search).
            params: Dict with 'topic' key specifying the research topic.

        Returns:
            Dict with status, message, and receipt containing findings.
        """
        params = params or {}
        topic = params.get("topic", "")

        if not topic:
            return {
                "status": "error",
                "message": "No research topic provided.",
                "receipt": None,
            }

        # Verify that the brain has web_search capability (GLM primary)
        has_web_search = hasattr(brain, "web_search") and callable(brain.web_search)
        if not has_web_search:
            # Fall back to the brain's GLM sub-brain if available
            if hasattr(brain, "glm_brain") and brain.glm_brain and brain.glm_brain.available():
                brain = brain.glm_brain
                has_web_search = True
            else:
                return {
                    "status": "error",
                    "message": "Web search not available. GLM web search is required for deep research.",
                    "receipt": None,
                }

        # Step 1: Broad search on the topic — this produces topic-specific URLs
        try:
            broad_results = await brain.web_search(topic)
        except Exception as exc:
            logger.error(f"Deep research broad search failed: {exc}")
            return {
                "status": "error",
                "message": f"Web search failed: {exc}",
                "receipt": None,
            }

        if not broad_results:
            return {
                "status": "error",
                "message": f"No results found for topic: {topic}",
                "receipt": None,
            }

        # Verify that results contain topic-relevant URLs (not hardcoded)
        urls_found = [
            r.get("url", "") for r in broad_results if r.get("url")
        ]
        if not urls_found:
            logger.warning(
                "Deep research: broad search returned results but no URLs — "
                "search may not be working correctly"
            )

        # Step 2: Generate sub-queries and do targeted searches
        # Each sub-query is derived from the topic, ensuring different
        # topics produce different queries and therefore different URLs.
        sub_queries = self._generate_sub_queries(topic, broad_results)

        detailed_results = {}
        for sq in sub_queries[:3]:  # Limit to 3 sub-queries
            try:
                results = await brain.web_search(sq)
                # Verify each sub-query also produces unique URLs
                sq_urls = [
                    r.get("url", "") for r in results if r.get("url")
                ]
                if sq_urls:
                    # Check that sub-query URLs differ from broad URLs
                    unique_urls = set(sq_urls) - set(urls_found)
                    if not unique_urls:
                        logger.info(
                            "Deep research: sub-query '%s' returned only "
                            "overlapping URLs — this is normal for narrow topics",
                            sq,
                        )
                detailed_results[sq] = results
            except Exception as exc:
                logger.warning(f"Sub-query search failed for '{sq}': {exc}")
                detailed_results[sq] = []

        # Step 3: Synthesize findings using the brain
        synthesis_prompt = self._build_synthesis_prompt(
            topic, broad_results, detailed_results
        )

        synthesis = ""
        try:
            async for chunk in brain.chat_stream(synthesis_prompt):
                synthesis += chunk
        except Exception as exc:
            logger.error(f"Deep research synthesis failed: {exc}")
            synthesis = "Synthesis unavailable due to LLM error."

        # Compile all findings with URL verification data
        all_urls = list(urls_found)
        for sq_results in detailed_results.values():
            for r in sq_results:
                url = r.get("url", "")
                if url and url not in all_urls:
                    all_urls.append(url)

        findings = {
            "topic": topic,
            "broad_results": [
                {
                    "title": r.get("title", ""),
                    "url": r.get("url", ""),
                    "snippet": r.get("snippet", ""),
                }
                for r in broad_results
            ],
            "detailed_queries": list(detailed_results.keys()),
            "total_unique_urls": len(set(all_urls)),
            "url_diversity_verified": len(set(all_urls)) > 1,
            "synthesis": synthesis,
            "researched_at": datetime.datetime.now().isoformat(),
        }

        return {
            "status": "success",
            "message": f"Deep research complete for: {topic}",
            "receipt": {
                "type": "deep_research",
                "data": findings,
                "timestamp": datetime.datetime.now().isoformat(),
            },
        }

    @staticmethod
    def _generate_sub_queries(topic: str, broad_results: list) -> list:
        """Generate sub-queries for deeper research based on broad results.

        Sub-queries are derived directly from the topic string, so
        different topics will always produce different queries.
        """
        sub_queries = [f"{topic} latest developments", f"{topic} analysis"]

        # Extract meaningful words from snippets to create targeted queries
        for result in broad_results[:3]:
            snippet = result.get("snippet", "")
            if snippet:
                # Take the first meaningful phrase from the snippet
                words = snippet.split()[:6]
                if len(words) >= 3:
                    sub_queries.append(f"{topic} {' '.join(words)}")

        return sub_queries

    @staticmethod
    def _build_synthesis_prompt(
        topic: str,
        broad_results: list,
        detailed_results: dict,
    ) -> str:
        """Build a prompt for the LLM to synthesize research findings."""
        prompt_parts = [
            f"Synthesize the following research findings about: {topic}\n\n",
            "## Broad Search Results:\n",
        ]

        for r in broad_results[:5]:
            prompt_parts.append(
                f"- {r.get('title', 'No title')}: "
                f"{r.get('snippet', 'No snippet')[:200]}\n"
            )

        prompt_parts.append("\n## Detailed Research:\n")
        for query, results in detailed_results.items():
            prompt_parts.append(f"\n### Query: {query}\n")
            for r in results[:3]:
                prompt_parts.append(
                    f"- {r.get('title', 'No title')}: "
                    f"{r.get('snippet', 'No snippet')[:200]}\n"
                )

        prompt_parts.append(
            "\nPlease provide a comprehensive synthesis of these findings, "
            "highlighting key insights, contradictions, and areas for further "
            "investigation. Be specific and cite the sources where possible."
        )

        return "".join(prompt_parts)
