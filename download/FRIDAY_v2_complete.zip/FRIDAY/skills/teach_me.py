"""Teach Me skill — Socratic teaching mode for developers.

Instead of just answering questions, Friday teaches concepts properly:
  - Uses the Socratic method (asks follow-up questions)
  - Checks comprehension with quick checks
  - Adjusts depth based on user responses
  - Tracks what you've learned over time in memory
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from skills.base import BaseSkill

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Concept tracking (stored in memory for cross-session continuity)
# ---------------------------------------------------------------------------

class LearningTracker:
    """Tracks concepts the user has learned + comprehension level."""

    def __init__(self):
        self._concepts: Dict[str, dict] = {}  # concept_name → {level, last_practiced, attempts}

    def record_attempt(self, concept: str, understood: bool) -> None:
        if concept not in self._concepts:
            self._concepts[concept] = {
                "level": 0,
                "attempts": 0,
                "successful": 0,
                "last_practiced": None,
            }
        c = self._concepts[concept]
        c["attempts"] += 1
        if understood:
            c["successful"] += 1
            c["level"] = min(c["level"] + 1, 5)  # 5 levels of mastery
        else:
            # Don't decrease level, but don't increase either
            pass
        import datetime
        c["last_practiced"] = datetime.datetime.now().isoformat()

    def get_concepts(self) -> List[dict]:
        return [{"concept": k, **v} for k, v in self._concepts.items()]

    def get_level(self, concept: str) -> int:
        return self._concepts.get(concept, {}).get("level", 0)


# ---------------------------------------------------------------------------
# Skill
# ---------------------------------------------------------------------------

class TeachMeSkill(BaseSkill):
    """Socratic teaching mode for developers."""

    def __init__(self):
        self.tracker = LearningTracker()

    @property
    def name(self): return "teach_me"

    @property
    def description(self): return (
        "Teach concepts using the Socratic method — asks follow-up questions, "
        "checks comprehension, adjusts depth based on responses."
    )

    @property
    def trigger_phrases(self): return [
        "teach me",
        "explain like I'm a beginner",
        "walk me through",
        "help me understand",
    ]

    async def run(self, brain, params=None) -> dict:
        """Run the teach-me skill.

        Params:
            - topic: the concept to teach
            - user_response: optional — the user's answer to the last question
            - step: "intro" | "question" | "evaluate" | "summary"
        """
        params = params or {}
        topic = params.get("topic", "")
        step = params.get("step", "intro")
        user_response = params.get("user_response", "")

        if not topic:
            return {
                "status": "error",
                "message": "What topic would you like to learn? Pass 'topic' in params.",
            }

        if step == "intro":
            return self._intro(topic)
        elif step == "question":
            return self._question(topic, params.get("question_num", 1))
        elif step == "evaluate":
            return await self._evaluate(brain, topic, user_response,
                                         params.get("question_num", 1))
        elif step == "summary":
            return self._summary(topic)
        return {"status": "error", "message": f"Unknown step: {step}"}

    # ------------------------------------------------------------------
    # Steps
    # ------------------------------------------------------------------

    def _intro(self, topic: str) -> dict:
        """Introduce the topic and check what the user already knows."""
        current_level = self.tracker.get_level(topic)
        return {
            "status": "success",
            "message": (
                f"Let's learn about {topic}!\n\n"
                f"I'll use the Socratic method — I'll ask questions to help you "
                f"discover the answer yourself, then check your understanding.\n\n"
                f"Your current level for '{topic}': {current_level}/5\n\n"
                f"Ready? Reply with step='question' to begin."
            ),
            "receipt": {
                "type": "skill_receipt",
                "data": {
                    "topic": topic,
                    "current_level": current_level,
                    "next_step": "question",
                },
            },
        }

    def _question(self, topic: str, question_num: int) -> dict:
        """Ask a Socratic question about the topic.

        The questions escalate in difficulty based on question_num.
        """
        questions = self._get_question_ladder(topic, question_num)
        if question_num > len(questions):
            return {
                "status": "success",
                "message": (
                    f"You've completed all questions for {topic}! "
                    f"Reply with step='summary' to see your progress."
                ),
                "receipt": {"type": "skill_receipt",
                            "data": {"next_step": "summary"}},
            }

        q = questions[question_num - 1]
        return {
            "status": "success",
            "message": f"Question {question_num}/{len(questions)}:\n\n{q}",
            "receipt": {
                "type": "skill_receipt",
                "data": {
                    "topic": topic,
                    "question_num": question_num,
                    "question": q,
                    "next_step": "evaluate",
                },
            },
        }

    async def _evaluate(self, brain, topic: str, user_response: str,
                        question_num: int) -> dict:
        """Evaluate the user's response and decide whether to advance."""
        if not user_response:
            return {
                "status": "error",
                "message": "Please provide your answer in 'user_response'.",
            }

        # Use brain to evaluate (or use simple heuristic if brain unavailable)
        understood = False
        feedback = ""
        try:
            if brain:
                prompt = (
                    f"A learner is studying '{topic}'. They were asked question "
                    f"#{question_num}. Their answer was:\n\n"
                    f"{user_response}\n\n"
                    f"Is this answer correct? Reply 'YES' or 'NO' followed by "
                    f"a 1-sentence explanation."
                )
                response = ""
                async for chunk in brain.chat_stream(prompt):
                    response += chunk
                if response.upper().startswith("YES"):
                    understood = True
                    feedback = response
                else:
                    understood = False
                    feedback = response
        except Exception as exc:
            # Heuristic fallback — count keywords
            understood = len(user_response.split()) >= 5
            feedback = (
                "Good attempt!" if understood else
                "Try to elaborate more — explain your reasoning."
            )

        self.tracker.record_attempt(topic, understood)
        new_level = self.tracker.get_level(topic)

        next_step = "question" if understood else "question"  # either way, ask another
        next_q = question_num + 1 if understood else question_num

        return {
            "status": "success",
            "message": (
                f"{'✓ Correct!' if understood else '✗ Not quite.'}\n\n"
                f"{feedback}\n\n"
                f"Your level for '{topic}': {new_level}/5\n\n"
                f"Reply with step='question', question_num={next_q} to continue."
            ),
            "receipt": {
                "type": "skill_receipt",
                "data": {
                    "topic": topic,
                    "understood": understood,
                    "new_level": new_level,
                    "next_step": next_step,
                    "next_question_num": next_q,
                },
            },
        }

    def _summary(self, topic: str) -> dict:
        """Show learning progress for the topic."""
        level = self.tracker.get_level(topic)
        mastery_msg = "You've mastered this topic!" if level >= 4 else "Keep practicing to advance."
        return {
            "status": "success",
            "message": (
                f"Learning summary for '{topic}':\n\n"
                f"  Mastery level: {level}/5\n"
                f"  Concepts tracked: {len(self.tracker.get_concepts())}\n\n"
                f"{mastery_msg}"
            ),
            "receipt": {
                "type": "skill_receipt",
                "data": {
                    "topic": topic,
                    "level": level,
                    "all_concepts": self.tracker.get_concepts(),
                },
            },
        }

    def _get_question_ladder(self, topic: str, question_num: int) -> List[str]:
        """Return a ladder of Socratic questions for the topic.

        For real implementation, these would be generated by GLM based on
        the topic. Here we return generic Socratic questions that work
        for any topic.
        """
        return [
            f"What do you already know about {topic}? (Don't worry if it's nothing — that's why we're here.)",
            f"In your own words, what is {topic}? Try to explain it as if teaching a friend.",
            f"What problem does {topic} solve? When would you use it?",
            f"What are the key components or steps involved in {topic}?",
            f"What's a common misconception about {topic}? Why is it wrong?",
            f"Give an example of {topic} in practice. Walk through it step by step.",
            f"What are the limitations or trade-offs of {topic}?",
            f"How does {topic} compare to alternatives? When would you choose it?",
        ]
