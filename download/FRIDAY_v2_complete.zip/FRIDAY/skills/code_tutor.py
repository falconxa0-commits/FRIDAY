"""Code Tutor Skill — helps with coding questions using GLM.

Uses GLMBrain for chat-based tutoring and Code Interpreter when
available for running code snippets.  Inherits from BaseSkill.
"""

import datetime
import logging
from typing import Optional

from skills.base import BaseSkill

logger = logging.getLogger(__name__)


class CodeTutorSkill(BaseSkill):
    """Interactive code tutor powered by GLM with optional code execution."""

    @property
    def name(self) -> str:
        return "CodeTutor"

    @property
    def description(self) -> str:
        return "Help with coding questions, explain concepts, and execute code examples."

    @property
    def trigger_phrases(self) -> list:
        return [
            "help me code", "explain code", "how do I write",
            "debug this", "code tutor", "teach me programming",
            "fix this code", "how does", "what is", "coding question",
        ]

    async def run(self, brain, params: Optional[dict] = None) -> dict:
        """Execute the code tutor skill.

        Args:
            brain: A GLMBrain instance (or any brain with chat_stream).
            params: Dict with 'question' key.

        Returns:
            Dict with status, message, and receipt.
        """
        params = params or {}
        question = params.get("question", "")

        if not question:
            return {
                "status": "error",
                "message": "No coding question provided.",
                "receipt": None,
            }

        # Step 1: Build a tutor-style system prompt
        tutor_prompt = (
            "You are an expert coding tutor. Your job is to:\n"
            "1. Explain concepts clearly with examples\n"
            "2. Write well-commented code snippets\n"
            "3. Point out common mistakes and pitfalls\n"
            "4. Suggest best practices\n"
            "5. When relevant, show how to test the code\n\n"
            "Respond to the following question:\n\n"
            f"{question}"
        )

        # Step 2: Get the tutoring response
        explanation = ""
        try:
            async for chunk in brain.chat_stream(tutor_prompt):
                explanation += chunk
        except Exception as exc:
            logger.error(f"Code tutor chat failed: {exc}")
            return {
                "status": "error",
                "message": f"Tutoring failed: {exc}",
                "receipt": None,
            }

        # Step 3: Try to extract and run code snippets using the code
        #         interpreter (if available)
        code_results = None
        extracted_code = self._extract_code_blocks(explanation)

        if extracted_code and hasattr(brain, "code_interpreter"):
            try:
                # Run the first code block as an example
                code_results = await brain.code_interpreter(extracted_code[0])
            except Exception as exc:
                logger.warning(f"Code interpreter failed (non-fatal): {exc}")
                code_results = {"status": "error", "output": str(exc)}

        receipt_data = {
            "question": question,
            "explanation_length": len(explanation),
            "code_extracted": len(extracted_code),
            "code_executed": code_results is not None,
            "code_output": code_results if code_results else None,
            "tutored_at": datetime.datetime.now().isoformat(),
        }

        return {
            "status": "success",
            "message": explanation[:500] + ("..." if len(explanation) > 500 else ""),
            "receipt": {
                "type": "code_tutor",
                "data": receipt_data,
                "timestamp": datetime.datetime.now().isoformat(),
            },
        }

    @staticmethod
    def _extract_code_blocks(text: str) -> list:
        """Extract code blocks from markdown-formatted text.

        Looks for ```language ... ``` blocks and returns the code content.
        """
        blocks = []
        in_block = False
        current_block = []

        for line in text.split("\n"):
            if line.strip().startswith("```") and not in_block:
                in_block = True
                current_block = []
            elif line.strip() == "```" and in_block:
                in_block = False
                code = "\n".join(current_block)
                if code.strip():
                    blocks.append(code)
            elif in_block:
                current_block.append(line)

        return blocks
