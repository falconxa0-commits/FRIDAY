import datetime
import os
from skills.base import BaseSkill

class MorningBriefing(BaseSkill):
    @property
    def name(self): return "morning_briefing"
    @property
    def description(self): return "Aggregates weather and calendar events for a daily summary."
    @property
    def trigger_phrases(self): return ["good morning", "morning briefing", "today's agenda"]

    async def run(self, brain, params=None):
        print("Friday: Commencing Morning Briefing skill...")
        location = os.getenv("FRIDAY_DEFAULT_LOCATION", "Lagos")
        # 1. Get Weather
        weather_res = await brain.connector.execute_action("Weather", "get_weather", {"location": location})
        # 2. Get Calendar
        calendar_res = await brain.connector.execute_action("Calendar", "get_todays_events")

        summary = f"Good morning. {weather_res.get('message', 'Weather unavailable')}. {calendar_res.get('message', 'Calendar unavailable')}."

        return {
            "status": "success",
            "message": summary,
            "receipt": {
                "type": "skill_receipt",
                "steps": [weather_res, calendar_res],
                "timestamp": datetime.datetime.now().isoformat()
            }
        }
