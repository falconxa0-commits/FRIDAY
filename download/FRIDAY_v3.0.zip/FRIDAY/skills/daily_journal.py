"""Daily Journal skill — auto-generates a daily summary from real data.

Pulls from actual data sources (ledger, pattern engine, cost tracker)
— never fabricates content.
"""
import datetime
import logging
from skills.base import BaseSkill

logger = logging.getLogger(__name__)


class DailyJournalSkill(BaseSkill):
    """Generates a real daily summary from actual Friday interaction logs."""

    @property
    def name(self): return "daily_journal"

    @property
    def description(self): return (
        "Generates a daily summary of what happened — actions taken, "
        "research done, goals progressed, patterns noticed, cost summary."
    )

    @property
    def trigger_phrases(self): return ["daily journal", "what happened today", "daily summary"]

    async def run(self, brain, params=None):
        params = params or {}
        sections = []

        # 1. Actions taken today (from ledger)
        try:
            from core.ledger import get_ledger
            ledger = get_ledger()
            today = datetime.date.today().isoformat()
            todays_actions = [
                e for e in ledger.get_audit_log()
                if e.get("timestamp", "").startswith(today)
            ]
            sections.append(f"**Actions Today:** {len(todays_actions)} actions logged.")
            for a in todays_actions[-5:]:
                sections.append(f"  - {a.get('component', '?')}.{a.get('action', '?')} → {a.get('status', '?')}")
        except Exception:
            sections.append("**Actions Today:** Ledger unavailable.")

        # 2. Goals progressed today
        try:
            from core.goals import GoalTracker
            gt = GoalTracker()
            todays_progress = gt.get_todays_progress()
            if todays_progress:
                sections.append(f"\n**Goals Progress:** {len(todays_progress)} goal(s) updated today.")
                for p in todays_progress:
                    sections.append(f"  - {p['description']}: {p['updates_today']} update(s)")
            else:
                sections.append("\n**Goals Progress:** No goal updates today.")
        except Exception:
            sections.append("\n**Goals Progress:** Goal tracker unavailable.")

        # 3. Cost summary
        try:
            from api.routes.stats import _request_log
            today_logs = [r for r in _request_log if r.get("timestamp", "").startswith(today)]
            total_cost = sum(r.get("cost_usd", 0) for r in today_logs)
            sections.append(f"\n**Cost Summary:** ${total_cost:.4f} across {len(today_logs)} requests.")
        except Exception:
            sections.append("\n**Cost Summary:** Stats unavailable.")

        # 4. Tomorrow's preparation
        try:
            from core.context import ContextAwareness
            ctx = ContextAwareness()
            mode = ctx.get_time_context()
            sections.append(f"\n**Current Mode:** {mode}")
        except Exception:
            pass

        summary = "\n".join(sections)

        # Store in memory
        if brain and hasattr(brain, 'memory') and brain.memory:
            try:
                brain.memory.store_conversation("assistant", f"[Daily Journal] {summary}")
            except Exception:
                pass

        return {
            "status": "success",
            "message": summary,
            "receipt": {
                "type": "skill_receipt",
                "data": {"date": today, "sections": len(sections)},
                "timestamp": datetime.datetime.now().isoformat(),
            },
        }
