"""Daily Journal skill — generates a real daily summary from actual Friday data.

NOT a reflection prompt — a real record synthesized from evidence.
Every section pulls from a real data source. If there's no data, says so honestly.
"""
import datetime
import logging
import os
from skills.base import BaseSkill

logger = logging.getLogger(__name__)


class DailyJournalSkill(BaseSkill):
    """Generates a real daily summary from actual Friday interaction logs."""

    @property
    def name(self): return "daily_journal"

    @property
    def description(self): return (
        "Generates a daily summary of what happened — actions taken, "
        "research done, goals progressed, patterns noticed, cost summary."
    )

    @property
    def trigger_phrases(self): return ["daily journal", "what happened today", "daily summary"]

    async def run(self, brain, params=None):
        params = params or {}
        today = datetime.date.today().isoformat()
        sections = []
        headline_parts = []

        # 1. Actions taken today (from ledger)
        try:
            from core.ledger import get_ledger
            ledger = get_ledger()
            todays_actions = [
                e for e in ledger.get_audit_log()
                if e.get("timestamp", "").startswith(today)
            ]
            if todays_actions:
                sections.append(f"**Actions Today:** {len(todays_actions)} actions logged.")
                for a in todays_actions[-5:]:
                    sections.append(f"  - {a.get('component', '?')}.{a.get('action', '?')} -> {a.get('status', '?')}")
                headline_parts.append(f"{len(todays_actions)} actions")
            else:
                sections.append("**Actions Today:** No actions logged today.")
        except Exception as e:
            sections.append(f"**Actions Today:** Ledger unavailable ({e}).")

        # 2. Goals progressed today
        try:
            from core.goals import GoalTracker
            gt = GoalTracker()
            todays_progress = gt.get_todays_progress()
            if todays_progress:
                sections.append(f"\n**Goals Progress:** {len(todays_progress)} goal(s) updated today.")
                for p in todays_progress:
                    sections.append(f"  - {p['description']}: {p['updates_today']} update(s)")
                headline_parts.append(f"{len(todays_progress)} goal updates")
            else:
                sections.append("\n**Goals Progress:** No goal updates today.")
        except Exception as e:
            sections.append(f"\n**Goals Progress:** Goal tracker unavailable ({e}).")

        # 3. Research done today
        try:
            from api.routes.stats import _request_log
            today_logs = [r for r in _request_log if r.get("timestamp", "").startswith(today)]
            research_count = len(today_logs)
            if research_count > 0:
                sections.append(f"\n**Research & Chat:** {research_count} API calls today.")
                headline_parts.append(f"{research_count} API calls")
            else:
                sections.append("\n**Research & Chat:** No API calls today.")
        except Exception:
            sections.append("\n**Research & Chat:** Stats unavailable.")

        # 4. Cost summary
        try:
            from api.routes.stats import _request_log
            today_costs = [r for r in _request_log if r.get("timestamp", "").startswith(today)]
            total_cost = sum(r.get("cost_usd", 0) for r in today_costs)
            sections.append(f"\n**Cost Summary:** ${total_cost:.4f} across {len(today_costs)} requests.")
            if total_cost == 0:
                sections.append("  (All calls on free tier — $0.00)")
        except Exception:
            sections.append("\n**Cost Summary:** Stats unavailable.")

        # 5. New things learned (corrections)
        try:
            from core.learning import FridayLearningSystem
            ls = FridayLearningSystem()
            corrections = ls.get_all_corrections()
            todays_corrections = [c for c in corrections if c.get("timestamp", "").startswith(today)]
            if todays_corrections:
                sections.append(f"\n**Learning:** {len(todays_corrections)} correction(s) recorded today.")
                for c in todays_corrections[:3]:
                    sections.append(f"  - Corrected: '{c['original'][:60]}' -> '{c['correction'][:60]}'")
                headline_parts.append(f"{len(todays_corrections)} corrections")
            else:
                sections.append("\n**Learning:** No corrections recorded today.")
        except Exception:
            sections.append("\n**Learning:** Learning system unavailable.")

        # 6. One honest insight (from pattern engine or subconscious)
        try:
            from database.subconscious import SubconsciousMind
            sub = SubconsciousMind()
            intuition = sub.get_intuition()
            if intuition and len(intuition) > 10:
                sections.append(f"\n**Insight:** {intuition[:200]}")
            else:
                sections.append("\n**Insight:** No patterns surfaced today.")
        except Exception:
            sections.append("\n**Insight:** Subconscious mind unavailable.")

        # 7. Tomorrow prep
        try:
            from core.context import ContextAwareness
            ctx = ContextAwareness()
            mode = ctx.get_time_context()
            sections.append(f"\n**Current Mode:** {mode}")
        except Exception:
            pass

        # Build headline
        if headline_parts:
            headline = f"Today: {', '.join(headline_parts)}."
        else:
            headline = "Today: A quiet day — no significant activity logged."

        summary = f"**{headline}**\n\n" + "\n".join(sections)

        # Store in memory
        if brain and hasattr(brain, 'memory') and brain.memory:
            try:
                brain.memory.store_conversation("assistant", f"[Daily Journal — {today}] {summary}")
            except Exception as e:
                logger.debug(f"Memory store failed: {e}")

        return {
            "status": "success",
            "message": summary,
            "receipt": {
                "type": "skill_receipt",
                "data": {"date": today, "sections": len(sections), "headline": headline},
                "timestamp": datetime.datetime.now().isoformat(),
            },
        }
