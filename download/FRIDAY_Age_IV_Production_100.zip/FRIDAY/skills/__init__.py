"""FRIDAY Skills Framework."""
from skills.base import BaseSkill
__all__ = ["BaseSkill"]
