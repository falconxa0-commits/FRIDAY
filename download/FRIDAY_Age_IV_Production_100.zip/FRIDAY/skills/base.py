"""Base class for all Friday Skills."""
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

class BaseSkill(ABC):
    @property
    @abstractmethod
    def name(self) -> str: ...
    @property
    @abstractmethod
    def description(self) -> str: ...
    @property
    def triggers(self) -> list[str]:
        return []
    @property
    def enabled(self) -> bool:
        return True
    @abstractmethod
    async def run(self, brain: Any, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]: ...
    def __repr__(self) -> str:
        return f"<Skill {self.name}: {self.description}>"
