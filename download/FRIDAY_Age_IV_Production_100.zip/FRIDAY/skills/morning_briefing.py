"""Morning Briefing skill."""
from __future__ import annotations
import datetime
from typing import Any, Dict, Optional
from skills.base import BaseSkill
class MorningBriefing(BaseSkill):
    @property
    def name(self) -> str: return "morning_briefing"
    @property
    def description(self) -> str: return "Generates a morning briefing."
    @property
    def triggers(self) -> list[str]: return ["morning briefing", "briefing"]
    async def run(self, brain: Any, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        now = datetime.datetime.now()
        return {"status": "success", "message": f"Morning Briefing — {now.strftime('%A')}", "skill": self.name, "timestamp": now.isoformat()}
