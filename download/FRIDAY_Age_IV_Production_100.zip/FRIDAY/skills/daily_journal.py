"""Daily Journal skill — end-of-day summary of actions, goals, and cost."""
from __future__ import annotations
import datetime
from typing import Any, Dict, Optional
from skills.base import BaseSkill


class DailyJournalSkill(BaseSkill):
    @property
    def name(self) -> str:
        return "daily_journal"

    @property
    def description(self) -> str:
        return "Generates an end-of-day journal summarizing actions, goals, and costs."

    @property
    def triggers(self) -> list[str]:
        return ["daily journal", "end of day", "journal entry"]

    async def run(self, brain: Any, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        now = datetime.datetime.now()
        date_str = now.strftime("%A, %d %B %Y")

        lines = [f"📓 Daily Journal — {date_str}", ""]

        # --- Actions Today (from ledger) ---
        lines.append("Actions Today:")
        actions_count = 0
        try:
            from core.ledger import get_ledger
            ledger = get_ledger()
            entries = ledger.get_audit_log()
            today_str = now.strftime("%Y-%m-%d")
            todays = [
                e for e in entries
                if (e.get("timestamp", "") or "").startswith(today_str)
                or today_str in (e.get("timestamp", "") or "")
            ]
            if not todays and entries:
                todays = entries[-5:]
            for e in todays[:10]:
                comp = e.get("component", "?")
                act = e.get("action", "?")
                st = e.get("status", "?")
                lines.append(f"  • {comp}.{act} — {st}")
                actions_count += 1
            if not todays:
                lines.append("  (no actions logged today)")
        except Exception as exc:
            lines.append(f"  (error reading ledger: {exc})")

        lines.append(f"({actions_count} actions logged total)")
        lines.append("")

        # --- Goals Progress ---
        lines.append("Goals Progress:")
        try:
            from core.goals import GoalTracker
            tracker = GoalTracker()
            goals = tracker.list_goals() if hasattr(tracker, "list_goals") else []
            if goals:
                for g in goals[:5]:
                    title = g.get("title") or g.get("description", "?")
                    progress = g.get("progress", 0)
                    status = g.get("status", "active")
                    lines.append(f"  • {title}: {progress}% ({status})")
            else:
                lines.append("  (no active goals)")
        except Exception:
            lines.append("  (goal tracker unavailable)")

        lines.append("")

        # --- Cost Summary ---
        lines.append("Cost Summary:")
        try:
            from core.cost_tracker import CostTracker
            ct = CostTracker()
            report = ct.get_cost_report()
            total = report.get("total_cost_usd", report.get("total_cost", 0.0))
            lines.append(f"  Total cost: ${total:.4f}")
        except Exception as exc:
            lines.append(f"  (cost tracker error: {exc})")

        lines.append("")
        lines.append(f"Generated at {now.strftime('%H:%M')}.")

        return {
            "status": "success",
            "message": "\n".join(lines),
            "skill": self.name,
            "actions_count": actions_count,
            "timestamp": now.isoformat(),
        }
