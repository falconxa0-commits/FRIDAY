# FRIDAY Core Package
