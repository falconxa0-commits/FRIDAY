# FRIDAY Config Package
