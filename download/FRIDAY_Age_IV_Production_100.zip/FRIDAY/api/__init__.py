# FRIDAY API Package
